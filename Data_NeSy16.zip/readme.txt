This is the data for the NeSy'16 Workshop paper "Inducing Symbolic Rules from Entity Embeddings using Auto-encoders"

Rules.txt = The JRIP output for our rules.
Class labels = The binary labels for all films in the top 2% of each cluster
Cluster names = The cluster centre names which we used in the rule output
Cluster classes = All properties similar to each cluster, arranged by amount of terms clustered
Discrete class labels = The discretized input vectors in buckets from 1-100%
Input Vectors = The non-discretized input vectors in the form of the dot product

Total of 15,000 films used.

The amount of phrases for the vectors and clusters is equal to the amount of dimensions of the space.